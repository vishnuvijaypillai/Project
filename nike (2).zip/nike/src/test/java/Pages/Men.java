package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import baseclass.WrapperClass;

public class Men extends WrapperClass {
	public static String s,a;
	public void Optionhover() throws InterruptedException
	{
		Actions actions = new Actions(driver);
		//men hover
		WebElement menuOption = driver.findElement(By.xpath("//*[@id=\"gen-nav-commerce-header\"]/header/nav[1]/section[2]/div/div[2]/ul/li[1]/a"));
		actions.moveToElement(menuOption).perform();
		TimeUnit.SECONDS.sleep(2);
	}
public void elementpresent()
{
	try
	{
		Actions actions = new Actions(driver);
		//newest sneakers 
		WebElement newest =driver.findElement(By.xpath("//a[@aria-label=\"MEN, SHOES, Newest Sneakers\"]"));
		actions.moveToElement(newest).click().build().perform();
		TimeUnit.SECONDS.sleep(4);
		System.out.println("Newest Sneakers is present");
	}
	catch(Exception e)
	{
		System.out.println("Newest Sneakers is not present");
	}
}

//testcase2
public void selectproduct() throws InterruptedException
{
	//first product
	By product=By.xpath("//*[@id=\"Wall\"]/div/div[6]/div[2]/main/section/div/div[1]/div/figure/a[2]/div/picture/img");
	s=driver.findElement(product).getAttribute("alt");
	System.out.println(s);
	driver.findElement(product).click();
	System.out.println("First product is selected");
	TimeUnit.SECONDS.sleep(2);
}

//testcase3
public void sizepresent()
{
	try
	{
		//driver.findElement(By.id("skuAndSize__24124481")).isDisplayed();
		//size 12
		driver.findElement(By.xpath("//*[@id=\"buyTools\"]/div[1]/fieldset/div/div[10]/label")).click();
		System.out.println("Size US 12 is present");
		TimeUnit.SECONDS.sleep(5);
	}
	catch(Exception e)
	{
		System.out.println("Size US 12 is not present");
	}
}

//testcase4
public void bag() throws InterruptedException
{
	//add to bag button
	driver.findElement(By.xpath("//*[@id=\"buyTools\"]/div[2]/button[1]")).click();
	System.out.println("The product is added to cart");
	TimeUnit.SECONDS.sleep(8);
	
}

//testcase5
public void addtocart() throws InterruptedException
{
	//cart button
	driver.findElement(By.xpath("//*[@id=\"gen-nav-commerce-header\"]/header/nav[1]/section[1]/div/div/ul[2]/li[3]/div/a/i")).click();
	TimeUnit.SECONDS.sleep(4);
	//attribute of product
	a=driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[2]/div[1]/figure/a/img")).getAttribute("alt");
	System.out.println(a);
	if(s.contains(a))
	{
		System.out.println("The product is in cart");
	}
	else
	{
		System.out.println("The product is not in cart");
	}
}


//testcase6
public void removefromcart() throws InterruptedException
{
	//cart button
	driver.findElement(By.xpath("//*[@id=\"gen-nav-commerce-header\"]/header/nav[1]/section[1]/div/div/ul[2]/li[3]/div/a/i")).click();
	TimeUnit.SECONDS.sleep(4);
	//remove option
	driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[2]/div/div[2]/ul/li[2]/button")).click();
	TimeUnit.SECONDS.sleep(5);
	try
	{
		//move to favourites option
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[2]/div/div[2]/ul/li[1]/button")).click();
		System.out.println("The product is not removed from cart");
	}
	catch(Exception e)
	{
		System.out.println("The product is removed from cart");
	}
}


//testcase7
public void hidefilters() throws InterruptedException
{
	//hide filters option
	driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[4]/header/nav/button/span")).click();
	TimeUnit.SECONDS.sleep(5);
	try
	{
		//lifestyle option
		if(driver.findElement(By.xpath("//*[@id=\"left-nav\"]/nav/div[2]/div/a[1]")).isDisplayed())
		{
		System.out.println("Lifestyle is present");
		}
		else
		{
			System.out.println("Lifestyle is not present");
		}

	}
	catch(Exception e)
	{
		driver.quit();
	}
	}

//testcase8
public void showfilters()
{
	//hide filters option
	//driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[4]/header/nav/button/span")).click();
	
	//show filters option
	driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[4]/header/nav/button/span")).click();
	try
	{
		//lifestyle option
		driver.findElement(By.xpath("//*[@id=\"left-nav\"]/nav/div[2]/div/a[1]")).isDisplayed();
		System.out.println("Lifestyle is present");
	}
	catch(Exception e)
	{
		System.out.println("Lifestyle is not present");
	}
}

//testcase9
public void sortbyhightolow() throws InterruptedException
{
	//sort by list
	driver.findElement(By.xpath("//*[@id=\"dropdown-btn\"]")).click();
	TimeUnit.SECONDS.sleep(2);
	
	//price:high-low
	driver.findElement(By.xpath("//*[@id=\"sort-options\"]/button[3]")).click();
	TimeUnit.SECONDS.sleep(4);
	
	//select highest price product
	driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[6]/div[2]/main/section/div/div[1]/div/figure/a[2]/div/picture/img")).click();
	TimeUnit.SECONDS.sleep(2);
	String highestname=driver.getTitle();
	highestname=highestname.substring(5, 38);
	System.out.println(highestname);
	
	//price of the product
	String highestprice=driver.findElement(By.xpath("//*[@id=\"RightRail\"]/div/div[1]/div/div[1]/div[2]/div/div")).getText();
	highestprice=highestprice.substring(1);
	System.out.println(highestprice);
}

//testcase10
public void sortbylowtohigh() throws InterruptedException
{
	//sort by list
	driver.findElement(By.xpath("//*[@id=\"dropdown-btn\"]")).click();
	TimeUnit.SECONDS.sleep(2);
	
	//price:low-high
	driver.findElement(By.xpath("//*[@id=\"sort-options\"]/button[4]")).click();
	TimeUnit.SECONDS.sleep(4);
	
	//select lowest price product
	driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[6]/div[2]/main/section/div/div[1]/div/figure/a[2]/div/picture/img")).click();
	TimeUnit.SECONDS.sleep(2);
	String lowestname=driver.getTitle();
	lowestname=lowestname.substring(0, 13);
	System.out.println(lowestname);
	
	//price of the product
	String lowestprice=driver.findElement(By.xpath("//*[@id=\"RightRail\"]/div/div[1]/div/div[1]/div[2]/div/div")).getText();
	lowestprice=lowestprice.substring(1);
	System.out.println(lowestprice);
}
}
