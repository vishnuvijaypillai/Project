package Pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import baseclass.WrapperClass;
import excelUtility.ExcelReadWrite;

public class Login extends WrapperClass {
	
	public void click() throws InterruptedException
{
	driver.findElement(By.xpath("//*[@id=\"AccountNavigationContainer\"]/button/span")).click();
	TimeUnit.SECONDS.sleep(2);
	//driver.findElement(By.name("emailAddress")).click();
}
	public void negativeDetails() throws IOException
	{
		ExcelReadWrite obj=new ExcelReadWrite();
		String email=obj.readExcelData("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx",1, 0);
		String password=obj.readExcelData("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx",1, 1);
		driver.findElement(By.name("emailAddress")).sendKeys(email);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("password")).submit();
		try
		{
			driver.findElement(By.id("MyAccountLink")).click();
			obj.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx","invalid credentials", 1, 2);
		}
		catch(Exception e)
		{
			obj.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx","invalid credentials", 1, 2);
		}
		}
	public void invalidPassword() throws IOException
	{
		ExcelReadWrite obj=new ExcelReadWrite();
		String email=obj.readExcelData("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx",3, 0);
		String password=obj.readExcelData("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx",3, 1);
		driver.findElement(By.name("emailAddress")).clear();
		driver.findElement(By.name("emailAddress")).sendKeys(email);
		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("password")).submit();
		try
		{
			driver.findElement(By.id("MyAccountLink")).click();
			obj.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx","invalid credentials", 3, 2);
		}
		catch(Exception e)
		{
			obj.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx","invalid credentials", 3, 2);
		}
		}
	public void positiveDetails() throws IOException, InterruptedException
	{
		ExcelReadWrite obj=new ExcelReadWrite();
		String email=obj.readExcelData("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx",2, 0);
		String password=obj.readExcelData("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx",2, 1);
		driver.findElement(By.name("emailAddress")).clear();
		driver.findElement(By.name("emailAddress")).sendKeys(email);
		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("password")).submit();
		TimeUnit.SECONDS.sleep(5);		
		try
		{
			Actions action = new Actions(driver);
			WebElement element = driver.findElement(By.id("MyAccountLink"));
			action.moveToElement(element).perform();
			obj.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx","valid credentials", 2, 2);
		}
		catch(Exception e)
		{
			obj.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx","invalid credentials", 2, 2);
		}
		
	TimeUnit.SECONDS.sleep(2);	
	}
}
