package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import baseclass.WrapperClass;

public class Logout extends WrapperClass {
	public void click() throws InterruptedException
	{
		Actions action = new Actions(driver);
		WebElement element = driver.findElement(By.xpath("//*[@id=\"MyAccountLink\"]/span"));
		action.moveToElement(element).perform();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.xpath("//*[@id=\"AccountNavigationDropdown-Menu\"]/div/ul/li[5]/button")).click();
		TimeUnit.SECONDS.sleep(5);
	}
}
