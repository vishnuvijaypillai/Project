package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import baseclass.WrapperClass;
import excelUtility.ExcelReadWrite;

public class AccountDetails extends WrapperClass{
//	WebDriver driver;
//	public AccountDetails(WebDriver driver)
//	{
//		this.driver=driver;
//	}
	public void click() throws InterruptedException
	{
		WrapperClass.driver.findElement(By.linkText("Account Settings")).click();
		TimeUnit.SECONDS.sleep(5);
	}
	public void editAboutMe() throws InterruptedException
	{
		//Actions action = new Actions(driver);
		//WebElement element = driver.findElement(By.xpath("//*[@id=\"MyAccountLink\"]"));
		//action.moveToElement(element).perform();
		driver.findElement(By.id("aboutMe")).sendKeys("Wakanda Forever");
		TimeUnit.SECONDS.sleep(4);
	}
}
