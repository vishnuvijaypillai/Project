package stepdefinitions;

import Pages.Customize;
import baseclass.WrapperClass;
import cucumber.api.java.en.When;

public class teststeps6 extends WrapperClass{
	@When("^User tries to customize shoes$")
	public void user_tries_to_customize_shoes() throws Exception {
	    Customize obj=new Customize();
	    obj.elementPresent();
	    obj.navigate();
	    obj.navigate2();
	    obj.hideFilter();
	    obj.showFilter();
	    obj.navigation3();
	}

}
