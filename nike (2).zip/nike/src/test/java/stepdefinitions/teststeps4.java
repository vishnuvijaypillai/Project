package stepdefinitions;

import Pages.Search;
import baseclass.WrapperClass;
import cucumber.api.java.en.When;

public class teststeps4 extends WrapperClass {
	Search obj=new Search();
	@When("^User searches for alphabets$")
	public void user_searches_for_alphabets() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   
	    obj.searchAlpha();
	}
	@When("^User searches for numbers$")
	public void user_searches_for_numbers() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    obj.searchNum();   
	}
	@When("^User searches for special characters$")
	public void user_searches_for_special_characters() throws Exception {
		 obj.searchSpecialChar();
	}

	@When("^User searches for alphanumeric values$")
	public void user_searches_for_alphanumeric_values() throws Exception {
		obj.searchAlphaNum();
	}
	@When("^User searches for multiple words$")
	public void user_searches_for_multiple_words() throws Exception {
	    obj.searchMutipleWords();
	}
}
