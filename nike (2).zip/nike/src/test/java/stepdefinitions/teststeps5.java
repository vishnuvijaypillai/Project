package stepdefinitions;

import Pages.Men;
import baseclass.WrapperClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class teststeps5 extends WrapperClass{

@When("^User checks if \"([^\"]*)\" present in Men Option$")
public void user_checks_if_present_in_Men_Option(String arg1) throws Exception {
	Men obj= new Men();
    obj.Optionhover();
   
}

@When("^User clicks \"([^\"]*)\"$")
public void user_clicks(String arg1) throws Exception {
	Men obj= new Men();
	obj.elementpresent();
	obj.hidefilters();
	obj.showfilters();
	obj.sortbyhightolow();
	obj.sortbylowtohigh();
   
}

@When("^User selects first product$")
public void user_selects_first_product() throws Exception {
	Men obj= new Men();
	obj.selectproduct();
}

@When("^User checks if US (\\d+) size is present and if present selects US (\\d+) size$")
public void user_checks_if_US_size_is_present_and_if_present_selects_US_size(int arg1, int arg2) throws Exception {
	Men obj= new Men();
	obj.sizepresent();
}


@Then("^User clicks \"([^\"]*)\" button1")
public void user_clicks_button1(String arg1) throws Exception {
	Men obj= new Men();
	obj.bag();
}

@When("^User clicks \"([^\"]*)\" and check if the selected product is present$")
public void user_clicks_and_check_if_the_selected_product_is_present(String arg1) throws Exception {
	Men obj= new Men();
	obj.addtocart();
	obj.removefromcart();
}


}
