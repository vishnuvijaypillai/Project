package stepdefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.AccountDetails;
import Pages.Login;
import baseclass.WrapperClass;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelUtility.ExcelReadWrite;

public class teststeps1 extends WrapperClass {
	
	@Given("^Website should be launched$")
	public void Website_should_be_launched() throws Exception {
	   
		launchApplication("chrome", "http://nike.com/in");
		
	}


	@When("^User clicks \"([^\"]*)\" button$")
	public void user_clicks_button(String arg1) throws Exception {
	    
		Login obj= new Login();
		obj.click();
		
	}

	@When("^User enters \"([^\"]*)\" in Email Address text field$")
	public void user_enters_in_Email_Address_text_field(String arg1) throws Exception {
		Login obj= new Login();
		ExcelReadWrite obj1=new ExcelReadWrite();
		int i; 
		String option;
		for(i=1;i<=3;i++)
		{
			option=obj1.readExcelData("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", i, 1);
			if(option.equals("Invalid Username and invalid Password"))
			{
				obj.negativeDetails();
			}
			if(option.equals("Invalid Password"))
			{
				obj.invalidPassword();
			}
			if(option.equals("Valid Username and valid Password"))
			{
				obj.positiveDetails();
			}
		}
		
	}
		
}
