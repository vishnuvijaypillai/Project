package stepdefinitions;

import Pages.Logout;
import baseclass.WrapperClass;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class teststeps3 extends WrapperClass {
	@When("^User clicks on \"([^\"]*)\" button$")
	public void user_clicks_on_button(String arg1) throws Exception {
		Logout obj=new Logout();
	    obj.click();
	   // driver.quit();
	}
}
