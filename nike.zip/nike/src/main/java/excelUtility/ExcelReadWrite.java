package excelUtility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadWrite {
	
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	FileInputStream inputStream;
	FileOutputStream outputStream;
		
	//To read excel data
	public String readExcelData(String path,int rowNumber, int colNumber) throws IOException 
	{
		inputStream = new FileInputStream(new File(path));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet("Sheet1");	
		
		XSSFRow row = sheet.getRow(rowNumber);
		XSSFCell cell = row.getCell(colNumber);
		
		String value = cell.getStringCellValue();
		return value;
	}
	
	//To write excel data
	public void writeExcelData(String path,String data) throws IOException
	{
		inputStream = new FileInputStream(new File(path));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet("Sheet1");	
		
		int maxRow = sheet.getLastRowNum() + 1;
		int cellnum = 0;
		
		XSSFRow row = sheet.createRow(maxRow);
		XSSFCell cell = row.createCell(cellnum++);
		cell.setCellValue(data);
		
		inputStream.close();
		
		outputStream = new FileOutputStream(new File(path));
		workbook.write(outputStream);
        outputStream.close();
	}
	public void writeDataToPosition(String path,String data,int r,int c) throws IOException
	{
		inputStream = new FileInputStream(new File(path));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet("Sheet1");	
		XSSFRow row = sheet.getRow(r);
		XSSFCell cell = row.createCell(c);
		cell.setCellValue(data);
		
		inputStream.close();
		
		outputStream = new FileOutputStream(new File(path));
		workbook.write(outputStream);
        outputStream.close();
	}
	
}

