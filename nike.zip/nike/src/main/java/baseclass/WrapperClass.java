package baseclass;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class WrapperClass {
	public static WebDriver driver;
	
	public void launchApplication(String browser, String url) {				
		try {
			//To launch firefox BROWSER
			if (browser.equalsIgnoreCase("firefox")) {
				//Gecko driver Root Path integration
				System.setProperty("webdriver.gecko.driver","src//test//resources//com//drivers//geckodriver.exe");
				//Creating an Object for Firefox Browser
				driver = new FirefoxDriver();
				
			}
			// TO launch Chrome Browser
			else if (browser.equalsIgnoreCase("chrome")) {
				//Chrome driver Root Path integration
				System.setProperty("webdriver.chrome.driver","C:\\Users\\ASHIR\\eclipse-workspace\\bmw\\src\\test\\resources\\com\\drivers\\chromedriver.exe");
				//Creating an Object for Chrome Browser
				driver=new ChromeDriver();

			}
       //to maximize the window
			driver.get(url);
			driver.manage().window().maximize(); 
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			
		
		} catch (WebDriverException e) {
			System.out.println(" browser could not be launched");
		}
	
	}
	// To Take Screenshot
	public void screenshot(String path) throws IOException
	{
		TakesScreenshot ts=((TakesScreenshot)driver);
		File Source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(Source,new File(path));
	}
	//To close the browser
   public void quit(){
		
		driver.quit();
   }

}

