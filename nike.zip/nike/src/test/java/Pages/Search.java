package Pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import baseclass.WrapperClass;
import excelUtility.ExcelReadWrite;

public class Search extends WrapperClass {
	ExcelReadWrite obj1=new ExcelReadWrite();
	public void searchAlpha() throws IOException, InterruptedException
	{
		
		String search=obj1.readExcelData("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", 9, 0);
		System.out.println(search);
		driver.findElement(By.id("TypeaheadSearchInput")).sendKeys(search);
		driver.findElement(By.xpath("//*[@id=\"gen-nav-commerce-header\"]/header/nav[1]/section[2]/div/div[3]/div[1]/div/div/div/button[2]")).click();
		TimeUnit.SECONDS.sleep(3);
		try
		{
		String str=driver.findElement(By.xpath("//*[@id=\"Results-for-<span>&quot;Lebron&quot;</span>\"]")).getText();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", "Valid data", 9, 2);
		}
		catch(Exception e)
		{
			obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", "Invalid data", 9, 2);
		}
		}
	public void searchNum() throws IOException, InterruptedException
	{
		
		String str1=driver.getCurrentUrl();
		String search=obj1.readExcelData("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", 10, 0);
		search=search.substring(1, 5);
		System.out.println(search);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.id("TypeaheadSearchInput")).clear();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.id("TypeaheadSearchInput")).sendKeys(search);
		driver.findElement(By.xpath("//*[@id=\"gen-nav-commerce-header\"]/header/nav[1]/section[2]/div/div[3]/div[1]/div/div/div/button[2]")).click();
		TimeUnit.SECONDS.sleep(4);
		String str=driver.getCurrentUrl();
		
			if(str.equals(str1))
			{
			obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", "Invalid data", 10, 2);		
			}
			else
			{
			obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", "Valid data", 10, 2);
			}
			}
	public void searchSpecialChar() throws IOException, InterruptedException
	{
		
		String str1=driver.getCurrentUrl();
		String search=obj1.readExcelData("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", 11, 0);
		System.out.println(search);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.id("TypeaheadSearchInput")).clear();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.id("TypeaheadSearchInput")).sendKeys(search);
		driver.findElement(By.xpath("//*[@id=\"gen-nav-commerce-header\"]/header/nav[1]/section[2]/div/div[3]/div[1]/div/div/div/button[2]")).click();
		TimeUnit.SECONDS.sleep(4);
		String str=driver.getCurrentUrl();
		if(str.equals(str1))
		{
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", "Invalid data", 11, 2);		
		}
		else
		{
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", "Valid data", 11, 2);
		}
		
	}
	public void searchAlphaNum() throws IOException, InterruptedException
	{
		String str1=driver.getCurrentUrl();
		String search=obj1.readExcelData("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", 12, 0);
		System.out.println(search);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.id("TypeaheadSearchInput")).clear();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.id("TypeaheadSearchInput")).sendKeys(search);
		driver.findElement(By.xpath("//*[@id=\"gen-nav-commerce-header\"]/header/nav[1]/section[2]/div/div[3]/div[1]/div/div/div/button[2]")).click();
		TimeUnit.SECONDS.sleep(4);
		String str=driver.getCurrentUrl();
		if(str.equals(str1))
		{
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", "Invalid data", 12, 2);		
		}
		else
		{
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", "Valid data", 12, 2);
		}
	}
	public void searchMutipleWords() throws IOException, InterruptedException
	{
		
		String search=obj1.readExcelData("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", 13, 0);
		System.out.println(search);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.id("TypeaheadSearchInput")).clear();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.id("TypeaheadSearchInput")).sendKeys(search);
		driver.findElement(By.xpath("//*[@id=\"gen-nav-commerce-header\"]/header/nav[1]/section[2]/div/div[3]/div[1]/div/div/div/button[2]")).click();
		TimeUnit.SECONDS.sleep(3);
		try
		{
		String str=driver.findElement(By.xpath("//*[@id=\"Results-for-<span>&quot;Lebron-shoes&quot;</span>\"]")).getText();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", "Valid data", 13, 2);
		}
		catch(Exception e)
		{
			obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata.xlsx", "Invalid data", 13, 2);
		}
		//driver.quit();	
	}

}
