package Pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import baseclass.WrapperClass;

public class Customize extends WrapperClass {
	public void elementPresent() throws InterruptedException
	{
		Actions action=new Actions(driver);
		WebElement element = driver.findElement(By.linkText("CUSTOMISE"));
		action.moveToElement(element).perform();
		List<WebElement> elements=driver.findElements(By.tagName("a"));
		TimeUnit.SECONDS.sleep(3);
		for(WebElement link:elements)
		{
			if(link.getText().equals("Girls"))
			{
				System.out.println(link.getText());
			}
		} 
	}
	public void elementNotPresent() throws InterruptedException
	{
		Actions action=new Actions(driver);
		WebElement element = driver.findElement(By.linkText("CUSTOMISE"));
		action.moveToElement(element).perform();
		List<WebElement> elements=driver.findElements(By.tagName("a"));
		TimeUnit.SECONDS.sleep(3);
		for(WebElement link:elements)
		{
			if(link.getText().equals("cricket"))
			{
				System.out.println(link.getText());
			}
		} 
	}
	public void navigate() throws InterruptedException
	{
		String str=driver.getCurrentUrl();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.xpath("//*[@id=\"NavigationMenu-3\"]/div/div[2]/a[4]")).click();
		TimeUnit.SECONDS.sleep(3);
		String str1=driver.getCurrentUrl();
		if(str.equals(str1))
		{
			System.out.println("Navigation unsuccessful");
		}
		else
		{
			System.out.println("Navigation Successful");
		}
	}
	public void navigate2() throws InterruptedException
	{
		TimeUnit.SECONDS.sleep(3);
		try
		{
			driver.findElement(By.xpath("//*[@id=\"left-nav\"]/nav/div[3]/div/div[2]/div/div/button[1]")).click();
		}
		catch(Exception e)
		{
		driver.findElement(By.xpath("//*[@id=\"left-nav\"]/nav/div[3]/div/div[2]/span/div")).click();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.xpath("//*[@id=\"left-nav\"]/nav/div[3]/div/div[2]/div/div/button[1]")).click();
		}
		TimeUnit.SECONDS.sleep(3);
		String str = driver.getCurrentUrl();
		TimeUnit.SECONDS.sleep(3);
		if(str.contains("black"))
		{
			System.out.println("Navigation Successful");
		}
		else
		{
			System.out.println("Navigation Unsuccessful");
		}
	}
	public void hideFilter() throws InterruptedException
	{
		driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[3]/header/nav/button")).click();
		TimeUnit.SECONDS.sleep(3);
		try
		{
			Actions action1 = new Actions(driver);
			WebElement element1 = driver.findElement(By.xpath("//*[@id=\\\"left-nav\\\"]/nav/div[3]/div/div[2]/span/div"));
			action1.moveToElement(element1).perform();
			//driver.findElement(By.xpath("//*[@id=\"left-nav\"]/nav/div[3]/div/div[2]/span/div")).click();
			System.out.println("Hide filters is not working");
		}
		catch(Exception e)
		{
			System.out.println("Successfully hided");
		}
	}
	public void showFilter() throws InterruptedException
	{
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[3]/header/nav/button")).click();
		TimeUnit.SECONDS.sleep(3);
		try
		{
			driver.findElement(By.xpath("//*[@id=\"left-nav\"]/nav/div[3]/div/div[2]/div/div/a")).click();
			TimeUnit.SECONDS.sleep(3);
			//driver.findElement(By.xpath("//*[@id=\"left-nav\"]/nav/div[3]/div/div[2]/span/div")).click();
			System.out.println("Show filters is working");
		}
		catch(Exception e)
		{
			System.out.println("Unsuccessful");
		}
		TimeUnit.SECONDS.sleep(3);
	}
	public void navigation3() throws InterruptedException
	{
		String str2=driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[5]/div[2]/main/section/div/div/div/figure/a[1]")).getText();
		System.out.println(str2);
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[5]/div[2]/main/section/div/div/div/figure/a[2]")).click();
		TimeUnit.SECONDS.sleep(3);
		String str3=driver.getTitle();
		TimeUnit.SECONDS.sleep(3);
		if(str3.contains(str2))
		{
			System.out.println("Navigation Successful");
		}
		else
		{
			System.out.println("Navigation Unsuccessful");
		}
	//driver.quit();
	}
}
