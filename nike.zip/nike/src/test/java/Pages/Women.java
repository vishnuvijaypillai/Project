package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import baseclass.WrapperClass;

public class Women extends WrapperClass{
	public void Optionhover() throws InterruptedException
	{
		Actions actions = new Actions(driver);
		//Women hover
		WebElement element = driver.findElement(By.xpath("//*[@id=\"gen-nav-commerce-header\"]/header/nav[1]/section[2]/div/div[2]/ul/li[2]/a"));
		actions.moveToElement(element).perform();
		TimeUnit.SECONDS.sleep(5);
	}
	public void selectAllShoes() throws InterruptedException
	{
		//clicking on the required keyword
		driver.findElement(By.xpath("//*[@id=\"NavigationMenu-1\"]/div/div[2]/a[2]")).click();
		TimeUnit.SECONDS.sleep(5);
	}
	public void hidingFilters() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[3]/header/nav/button")).click();
		TimeUnit.SECONDS.sleep(5);
		//checking weather filters are hidden
		try {
		driver.findElement(By.xpath("//*[@id=\"left-nav\"]/nav/div[2]/div/a[5]")).click();
		}

		catch (Exception e) {
		// TODO: handle exception
		System.out.println("the filters are hidden");
		}
	}
	public void showFilters() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[3]/header/nav/button/span")).click();
		TimeUnit.SECONDS.sleep(5);
	}
	public void selectProduct() throws InterruptedException {
		WebElement productname = driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[5]/div[2]/main/section/div/div[1]/div/figure/a[1]"));
		String s= productname.getText();
		driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[5]/div[2]/main/section/div/div[1]/div/figure/a[2]/div/picture/img")).click();
		TimeUnit.SECONDS.sleep(5);
		//Checking is it selected
		String productTitle =driver.getTitle();
		if(productTitle.contains(s))
		{
		System.out.println(s);
		}
	}
	public void selecctSize() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"buyTools\"]/div[1]/fieldset/div/div[8]/label")).click();
		TimeUnit.SECONDS.sleep(5);

	}
	public void addToBag() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"buyTools\"]/div[2]/button[1]")).click();
		TimeUnit.SECONDS.sleep(10);
	}
	public void checkCart() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"gen-nav-commerce-header\"]/header/nav[1]/section[1]/div/div/ul[2]/li[3]/div/a/i")).click();
		TimeUnit.SECONDS.sleep(5);
	}
	public void removeCart() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[2]/div[1]/div[2]/div/div[2]/ul/li[2]/button")).click();
		TimeUnit.SECONDS.sleep(5);
	}
	public void home() throws InterruptedException {
		 driver.findElement(By.xpath("//*[@id=\"gen-nav-commerce-header\"]/header/nav[1]/section[2]/div/div[1]/a/i")).click();
		 TimeUnit.SECONDS.sleep(5);
	}
	public void sortBy() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"dropdown-btn\"]/span[1]")).click();
		TimeUnit.SECONDS.sleep(5);
	}
	public void highestToLowest() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"sort-options\"]/button[3]")).click();
		TimeUnit.SECONDS.sleep(5);	
		}
	public void highestProduct() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[5]/div[2]/main/section/div/div[1]/div/figure/a[2]/div/picture/img")).click();
		TimeUnit.SECONDS.sleep(5);
		}
	public void highestProductDetails() throws InterruptedException {
		String highestname=driver.getTitle();
		System.out.println(highestname);
		String highestprice=driver.findElement(By.xpath("//*[@id=\"RightRail\"]/div/div[1]/div/div[1]/div[2]/div/div")).getText();
		highestprice=highestprice.substring(1);
		System.out.println(highestprice);
		}
	
}
