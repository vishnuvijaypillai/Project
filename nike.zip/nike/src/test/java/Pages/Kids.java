package Pages;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import baseclass.WrapperClass;

public class Kids extends WrapperClass {
	public void findElement()
	{
		//hover on Kids
		Actions action=new Actions(driver);
		WebElement element = driver.findElement(By.linkText("KIDS"));
		action.moveToElement(element).perform();


		//finding a keyword
		List<WebElement> elements=driver.findElements(By.tagName("a"));
		for(WebElement link:elements)
		{
		if(link.getText().equals("Balls"))
		{
		System.out.println(link.getText());
		}
		}

	}
	public void selectElement() throws InterruptedException
	{
		//clicking on the required keyword
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.xpath("//*[@id=\"NavigationMenu-2\"]/div/div[4]/a[2]")).click();
		TimeUnit.SECONDS.sleep(3);
		WebElement ele = driver.findElement(By.tagName("h1"));
		if(ele.getText().contains("Balls"))
		{
		System.out.println(ele.getText());
		}
	}
	public void selectColor() throws InterruptedException
	{
		//selecting the red
		try
		{
		driver.findElement(By.xpath("//*[@id=\"left-nav\"]/nav/div[3]/div/div[1]/div/div/button[1]")).click();
		TimeUnit.SECONDS.sleep(3);
		}
		catch (Exception e)
		{
		driver.findElement(By.xpath("//*[@id=\"left-nav\"]/nav/div[3]/div/div[1]/span/div")).click();
		driver.findElement(By.xpath("//*[@id=\"left-nav\"]/nav/div[3]/div/div[1]/div/div/button[1]")).click();
		}
		String link = driver.getCurrentUrl();
		if (link.contains("red"))
		{
		System.out.println(link);
		}
		TimeUnit.SECONDS.sleep(3);
	}
	public void selectProduct() throws InterruptedException
	{
		// selecting the first product
		String product = driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[6]/div[2]/main/section/div/div/div/figure/a[2]")).getAttribute("aria-describedby");
		System.out.println(product);
		driver.findElement(By.xpath("//*[@id=\"Wall\"]/div/div[6]/div[2]/main/section/div/div/div/figure/a[2]/div/picture/img")).click();
		TimeUnit.SECONDS.sleep(3);
		List<WebElement> productTitle =driver.findElements(By.xpath("//h1"));

		//checking wheather the product is selected
		for(WebElement text:productTitle)
		{
		System.out.println(text.getText());

		if(text.getText().equals(product))
		{
		System.out.println(text.getText());

		}
		}

	}
	public void selectSize() throws InterruptedException
	{
		//selecting the size
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.xpath("//*[@id=\"buyTools\"]/div[1]/fieldset/div/div[3]/label")).click();
	}
	public void addCart() throws InterruptedException
	{
		//add to bag
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.xpath("//*[@id=\"buyTools\"]/div[2]/button[1]")).click();
		TimeUnit.SECONDS.sleep(3);
	}
}
