package stepdefinitions;

import Pages.Women;
import baseclass.WrapperClass;
import cucumber.api.java.en.When;
import excelUtility.ExcelReadWrite;

public class teststeps8 extends WrapperClass {
	@When("^user tries to buy women's shoes$")
	public void user_tries_to_buy_women_s_shoes() throws Exception {
		Women obj=new Women();
	   obj.Optionhover();
	   obj.selectAllShoes();
	   ExcelReadWrite obj1=new ExcelReadWrite();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Element found", 39, 2);
	   obj.hidingFilters();
	   obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Filter Hidden", 40, 2);
	   obj.showFilters();
	   obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Filter showen", 41, 2);
	   obj.selectProduct();
	   obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Product Selected", 42, 2);
	   obj.selecctSize();
	   obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Size Selected", 43, 2);
	   obj.addToBag();
	   obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Added to Bag", 44, 2);
	   obj.checkCart();
	   obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Item Found", 45, 2);
	   obj.removeCart();
	   obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Removedd from Cart", 46, 2);
	   obj.home();
	    obj.Optionhover();
	   //obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Element found", 39, 2);
	   obj.selectAllShoes();
	   //obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Element found", 39, 2);
	   obj.sortBy();
	   //obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Element found", 39, 2);
	   obj.highestToLowest();
	   obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Selected", 47, 2);
	   obj.highestProduct();
	   obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Element found", 48, 2);
	   obj.highestProductDetails();
	   obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "details verified", 49, 2);
	   quit();
	}
}
