package stepdefinitions;

import Pages.Kids;
import baseclass.WrapperClass;
import cucumber.api.java.en.When;
import excelUtility.ExcelReadWrite;

public class teststeps7 extends WrapperClass{
	@When("^User tries to buy Kid's ball$")
	public void user_tries_to_buy_Kid_s_ball() throws Exception {
	    Kids obj=new Kids();
	    obj.findElement();
	    ExcelReadWrite obj1=new ExcelReadWrite();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Element found", 32, 2);
	    obj.selectElement();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Element successfully selected", 33, 2);
	    obj.selectColor();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Color selected successfully", 34, 2);
	    obj.selectProduct();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Product selected successfully", 35, 2);
	    obj.selectSize();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Size selected", 36, 2);
	    obj.addCart();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Item added to cart", 37, 2);
	    //driver.quit();
	}


}
