package stepdefinitions;

import Pages.Customize;
import baseclass.WrapperClass;
import cucumber.api.java.en.When;
import excelUtility.ExcelReadWrite;

public class teststeps6 extends WrapperClass{
	@When("^User tries to customize shoes$")
	public void user_tries_to_customize_shoes() throws Exception {
	    Customize obj=new Customize();
	    obj.elementPresent();
	    ExcelReadWrite obj1=new ExcelReadWrite();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Element is present", 24, 2);
	    obj.elementNotPresent();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Element is not present", 25, 2);
	    obj.navigate();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Navigation Successful", 26, 2);
	    obj.navigate2();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Color selected Successfully", 27, 2);
	    obj.hideFilter();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Filters hided successfully", 28, 2);
	    obj.showFilter();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Filters shown successfully", 29, 2);
	    obj.navigation3();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Customized shoes selected", 30, 2);
	}

}
