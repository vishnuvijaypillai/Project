package stepdefinitions;

import Pages.Men;
import baseclass.WrapperClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelUtility.ExcelReadWrite;

public class teststeps5 extends WrapperClass{

@When("^User checks if \"([^\"]*)\" present in Men Option$")
public void user_checks_if_present_in_Men_Option(String arg1) throws Exception {
	Men obj= new Men();
    obj.Optionhover();
    
}

@When("^User clicks \"([^\"]*)\"$")
public void user_clicks(String arg1) throws Exception {
	Men obj= new Men();
	obj.elementpresent();
	ExcelReadWrite obj1=new ExcelReadWrite();
	obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Element is present", 14, 2);
	obj.hidefilters();
	obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Hiding done successfully", 15, 2);
	obj.showfilters();
	obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Filters shown", 16, 2);
	obj.sortbyhightolow();
	obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Sorting done successfully", 17, 2);
	obj.Optionhover();
	obj.elementpresent();
	obj.sortbylowtohigh();
	obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Sorted successfully", 18, 2);
   
}

@When("^User selects first product$")
public void user_selects_first_product() throws Exception {
	Men obj= new Men();
	 obj.Optionhover();
	 obj.elementpresent();
	obj.selectproduct();
	ExcelReadWrite obj1=new ExcelReadWrite();
	obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Selection done successfully", 19, 2);
	
}

@When("^User checks if US (\\d+) size is present and if present selects US (\\d+) size$")
public void user_checks_if_US_size_is_present_and_if_present_selects_US_size(int arg1, int arg2) throws Exception {
	Men obj= new Men();
	obj.sizepresent();
	ExcelReadWrite obj1=new ExcelReadWrite();
	obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Size 12 found successfully", 20, 2);
}


@Then("^User clicks \"([^\"]*)\" button1")
public void user_clicks_button1(String arg1) throws Exception {
	Men obj= new Men();
	obj.bag();
}

@When("^User clicks \"([^\"]*)\" and check if the selected product is present$")
public void user_clicks_and_check_if_the_selected_product_is_present(String arg1) throws Exception {
	Men obj= new Men();
	obj.addtocart();
	ExcelReadWrite obj1=new ExcelReadWrite();
	obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Item added successfully", 21, 2);
	obj.removefromcart();
	obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Item removed successfully", 22, 2);
}


}
