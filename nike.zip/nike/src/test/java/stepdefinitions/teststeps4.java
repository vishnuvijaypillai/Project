package stepdefinitions;

import Pages.Search;
import baseclass.WrapperClass;
import cucumber.api.java.en.When;
import excelUtility.ExcelReadWrite;

public class teststeps4 extends WrapperClass {
	Search obj=new Search();
	@When("^User searches for alphabets$")
	public void user_searches_for_alphabets() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   
	    obj.searchAlpha();
	    ExcelReadWrite obj1=new ExcelReadWrite();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Search  Successful", 8, 2);
	}
	@When("^User searches for numbers$")
	public void user_searches_for_numbers() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    obj.searchNum();   
	    ExcelReadWrite obj1=new ExcelReadWrite();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Search Successful", 9, 2);
	}
	@When("^User searches for special characters$")
	public void user_searches_for_special_characters() throws Exception {
		 obj.searchSpecialChar();
		 ExcelReadWrite obj1=new ExcelReadWrite();
			obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Search unsuccessful", 10, 2);
		 screenshot("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\Screenshots\\search.jpg");
	}

	@When("^User searches for alphanumeric values$")
	public void user_searches_for_alphanumeric_values() throws Exception {
		obj.searchAlphaNum();
		ExcelReadWrite obj1=new ExcelReadWrite();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Search Successful", 11, 2);
	}
	@When("^User searches for multiple words$")
	public void user_searches_for_multiple_words() throws Exception {
	    obj.searchMutipleWords();
	    ExcelReadWrite obj1=new ExcelReadWrite();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Search Successful", 12, 2);
		int i;
		
	}
}
