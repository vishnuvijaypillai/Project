package stepdefinitions;

import org.openqa.selenium.WebDriver;

import Pages.AccountDetails;
import baseclass.WrapperClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelUtility.ExcelReadWrite;

public class teststeps2 extends WrapperClass {
	AccountDetails obj2 =new AccountDetails();
	
	@Given("^\"([^\"]*)\" should be clicked$")
	public void should_be_clicked(String arg1) throws Exception {
		
		obj2.click();
	}

	@When("^User enters \"([^\"]*)\" in about me text field$")
	public void user_enters_in_about_me_text_field(String arg1) throws Exception {
	 
		obj2.editAboutMe();
		ExcelReadWrite obj1=new ExcelReadWrite();
		obj1.writeDataToPosition("C:\\Users\\ASHIR\\eclipse-workspace\\nike\\src\\test\\resources\\testdata\\testdata1.xlsx", "Edit Successful", 5, 2);
		
		}
	
}
